---
name: Help wanted
about: Describe this issue template's purpose here.
title: "[HELP]"
labels: help wanted
assignees: ''

---

**Filterizr version**
Which version of Filterizr do you have installed in your project?

**Describe the issue in details**
Add any other context about the problem here.
